<?php
namespace Omeka\Mvc\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
