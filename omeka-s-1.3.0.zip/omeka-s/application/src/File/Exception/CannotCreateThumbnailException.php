<?php
namespace Omeka\File\Exception;

class CannotCreateThumbnailException extends RuntimeException
{
}
