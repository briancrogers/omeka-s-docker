<?php
/**
 * Created by IntelliJ IDEA.
 * User: gtierney
 * Date: 08/08/18
 * Time: 20:50
 */

namespace Digirati\OmekaShared\Framework;


class AbstractOmekaModule
{

}