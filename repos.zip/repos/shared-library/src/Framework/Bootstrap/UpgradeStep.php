<?php
/**
 * Created by IntelliJ IDEA.
 * User: gtierney
 * Date: 08/08/18
 * Time: 20:51
 */

namespace Digirati\OmekaShared\Framework\Bootstrap;


class UpgradeStep
{

}