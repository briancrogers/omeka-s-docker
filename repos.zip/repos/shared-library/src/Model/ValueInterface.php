<?php

namespace Digirati\OmekaShared\Model;


interface ValueInterface
{
    public function export();
}
