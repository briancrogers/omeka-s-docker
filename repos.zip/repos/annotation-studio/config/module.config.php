<?php

return [
    'view_manager' => [
        'template_path_stack' => [
            realpath(__DIR__.'/../view'),
        ],
    ],
];
