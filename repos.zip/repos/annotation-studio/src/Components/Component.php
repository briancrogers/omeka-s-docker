<?php

namespace AnnotationStudio\Components;

interface Component
{
    public function getBehaviour(): string;
}
