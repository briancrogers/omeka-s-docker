<?php

namespace IIIFStorage\Media;


interface TranslatableRenderer
{
    public function getTranslatableFieldNames(): array;
}
