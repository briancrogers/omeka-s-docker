<?php

namespace IIIFStorage\Media;


interface LocalisedMedia
{
    public function getLang(): string;
}
