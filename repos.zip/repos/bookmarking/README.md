# Bookmarking module
This bookmarking module adds UI components for bookmarking items. You can pull in the bookmark form 
into your templates and have the UI for bookmarking available.

The bookmarking module will fire an event that can be picked up and reacted to as needed. You can
see an implementation of this in the Elucidate module.
