<?php

return [
    'controller_plugins' => [
        'factories' => [
        ],
        'aliases' => [
        ],
    ],
];
