# Usage

Checklist for files to change

- package.json (namespace/psr)
- config/module.ini
- Module.php (namespace)
- 