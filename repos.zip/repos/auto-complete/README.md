# Autocomplete module

This module adds a lightweight autocomplete endpoint for:
- Omeka items
- [Worldcat Fast](http://id.worldcat.org)

Can be used to enrich content in frontend or backend components, but generally aimed at driving autocomplete
user interfaces.
