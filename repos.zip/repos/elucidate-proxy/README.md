# Elucidate proxy

This is a proxy for an annotation server that adds an event system to allow
you to hook into events in Elucidate regardless of where they were performed.
It also adds correct CORS headers, and authentication through Omeka's user
system.
